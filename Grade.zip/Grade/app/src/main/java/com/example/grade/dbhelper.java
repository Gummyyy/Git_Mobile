package com.example.grade;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import static com.example.grade.Constants.GRADE;
import static com.example.grade.Constants.TABLE_NAME;
import static com.example.grade.Constants.SUBJECT;
import static com.example.grade.Constants._ID;

import javax.security.auth.Subject;

public class dbhelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "Gradecalculator.db";
    private static final int DATABASE_VERSION = 2;
    public dbhelper(Context context){
        super(context, DATABASE_NAME,null,DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE " + TABLE_NAME + " (" + _ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + SUBJECT + " TEXT NOT NULL, " + GRADE + " TEXT NOT NULL);");
        db.execSQL("CREATE UNIQUE INDEX idx_GradeList_subject ON " + TABLE_NAME + " (" + SUBJECT +");");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db,int oldVersion, int newVersion){

        onCreate(db);
    }
}
