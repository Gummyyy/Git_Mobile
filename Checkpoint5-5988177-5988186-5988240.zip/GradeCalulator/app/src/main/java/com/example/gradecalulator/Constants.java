package com.example.gradecalulator;


import android.provider.BaseColumns;
public interface Constants extends BaseColumns {
    // class for create the constant value using in database function
   // public static final String TABLE_NAME = "GradeList";
    public static final String SUBJECT = "subject";
    public static final String GRADE = "grade";
}